export const blockClassNameIdentifiers={
    survey: 'calderaMailchimpSurvey',
    signup: 'calderaMailchimp',
};