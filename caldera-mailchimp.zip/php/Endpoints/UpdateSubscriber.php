<?php


namespace calderawp\CalderaMailChimp\Endpoints;


use calderawp\CalderaMailChimp\Controllers\HasModule;

class UpdateSubscriber extends \something\Mailchimp\Endpoints\UpdateSubscriber
{
	use HasModule;
}
